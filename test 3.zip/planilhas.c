#include <gtk/gtk.h>
#include <stdlib.h>

void open_file(const char *filename) {
    char command[256];
    snprintf(command, sizeof(command), "start %s", filename);
    system(command);
}

void on_button_clicked(GtkWidget *widget, gpointer data) {
    const char *filename = (const char *)data;
    open_file(filename);
}

int main(int argc, char *argv[]) {
    gtk_init(&argc, &argv);

    GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Escolha uma Planilha");
    gtk_window_set_default_size(GTK_WINDOW(window), 500, 400);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

    GtkWidget *vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
    gtk_container_add(GTK_CONTAINER(window), vbox);

    
    const char *file1 = "AdmissaoLaqueadura.xlsx"; 
    const char *file2 = "Admissaoginecologia.xlsx";
    const char *file3 = "HisteroscopiaCirurgica.xlsx";

    GtkWidget *button1 = gtk_button_new_with_label("Abrir Admissao cirurgica em Laqueadura");
    g_signal_connect(button1, "clicked", G_CALLBACK(on_button_clicked), (gpointer)file1);
    gtk_box_pack_start(GTK_BOX(vbox), button1, TRUE, TRUE, 0);

    GtkWidget *button2 = gtk_button_new_with_label("Abrir Admissao cirurgica para cirurgia geral em ginecologia");
    g_signal_connect(button2, "clicked", G_CALLBACK(on_button_clicked), (gpointer)file2);
    gtk_box_pack_start(GTK_BOX(vbox), button2, TRUE, TRUE, 0);

    GtkWidget *button3 = gtk_button_new_with_label("Abrir Histeroscopia Cirurgica");
    g_signal_connect(button3, "clicked", G_CALLBACK(on_button_clicked), (gpointer)file3);
    gtk_box_pack_start(GTK_BOX(vbox), button3, TRUE, TRUE, 0);

    gtk_widget_show_all(window);
    gtk_main();

    return 0;
}
